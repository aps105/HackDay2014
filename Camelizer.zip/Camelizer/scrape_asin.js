(function() {
  var input = document.getElementById("ASIN");
  var asin = input.value;
  return {"asin": asin};
})();
