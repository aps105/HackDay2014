(function() {
  span = document.getElementById('camelizer_version');
  span.textContent = "2.4.2";
  return true;
})();
